import { StyleSheet, Text, View, Image } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.cabecalho}>
        <Image
          style={styles.foto}
          source={require('./src/img/eu.png')}
        />
        <Text style={styles.nome}>Gabriel Gustavo</Text>
        <Text style={styles.profissao}>Desenvolvedor & Mecatrônico</Text>
      </View>

      <View style={styles.secao}>
        <Text style={styles.tituloSecao}>CONTATO</Text>
        <Text style={styles.texto}>Telefone: 11 97755-0227</Text>
        <Text style={styles.texto}>Email: gabrielgbatista1904@gmail.com</Text>
        <Text style={styles.texto}>Endereço: Rua dos Têxteis 1421, 22c</Text>
        <Text style={styles.texto}>CEP: 08490-600</Text>
      </View>

      <View style={styles.secao}>
        <Text style={styles.tituloSecao}>RESUMO</Text>
        <Text style={styles.texto}>
          Estudante de Desenvolvimento de Sistemas e Mecatrônica na ETEC de 
          Cidade Tiradentes e SENAI Roberto Simonsen. Busco oportunidade para 
          aplicar meus conhecimentos técnicos.
        </Text>
      </View>

      <View style={styles.secao}>
        <Text style={styles.tituloSecao}>FORMAÇÃO</Text>
        <Text style={styles.texto}>• Técnico em Desenvolvimento de Sistemas (2024-2026)</Text>
        <Text style={styles.texto}>• Técnico em Mecatrônica (Cursando)</Text>
        <Text style={styles.texto}>• Ensino Médio - ETEC de Cidade Tiradentes</Text>
      </View>


      <View style={styles.secao}>
        <Text style={styles.tituloSecao}>HABILIDADES</Text>
        <Text style={styles.texto}>• HTML, CSS, JavaScript, Java</Text>
        <Text style={styles.texto}>• Node.js, SQL Server</Text>
        <Text style={styles.texto}>• Torno CNC, Fresadora</Text>
        <Text style={styles.texto}>• Circuitos elétricos e eletrônicos</Text>
        <Text style={styles.texto}>• Inglês e Espanhol básico</Text>
      </View>


      <View style={styles.secao}>
        <Text style={styles.tituloSecao}>EXPERIÊNCIA</Text>
        <Text style={styles.texto}>Buscando primeira oportunidade profissional</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  cabecalho: {
    alignItems: 'center',
    marginBottom: 20,
    backgroundColor: '#4682B4',
    padding: 20,
    borderRadius: 10,
  },
  foto: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3,
    borderColor: '#fff',
    marginBottom: 10,
    backgroundColor: '#ddd',
  },
  nome: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  profissao: {
    fontSize: 16,
    color: '#fff',
    opacity: 0.9,
  },
  secao: {
    marginBottom: 20,
    backgroundColor: '#f0f8ff',
    padding: 15,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#4682B4',
  },
  tituloSecao: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 10,
  },
  texto: {
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
    lineHeight: 20,
  },
});